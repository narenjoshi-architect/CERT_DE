# Databricks Certified Data Engineer Associate

This repository contains the resources of the preparation course for Databricks Data Engineer Associate certification exam on Udemy:

<a href="https://www.udemy.com/course/databricks-certified-data-engineer-associate/?referralCode=F0FA48E9A0546C975F14" target="_blank">https://www.udemy.com/course/databricks-certified-data-engineer-associate/?referralCode=F0FA48E9A0546C975F14</a>.<br/>


To import these resources into your Databricks workspace, clone this repository via Databricks Repos.
